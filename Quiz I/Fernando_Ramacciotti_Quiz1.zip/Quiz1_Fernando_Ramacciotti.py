import pandas as pd
import os
import numpy as np
from scipy import stats

import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.graphics.api import qqplot


pathname = 'C:\\Users\\Ferna\\OneDrive\\Documentos\\Documentos Fernando\\MPE\\Econometria Series Financeiras\\Quiz I\\'
TimeSeriesXL = pd.ExcelFile(os.path.join(pathname, 'SeriesTemporaisHardcoded.xlsx'))

AllAssetClasses = pd.DataFrame()

for asset_class in TimeSeriesXL.sheet_names:
    print(asset_class)
    df = TimeSeriesXL.parse(asset_class,index_col=0,skiprows=1)
    df.columns = [asset_class]
    df.index.name = 'Dates'
    AllAssetClasses = pd.concat([AllAssetClasses,df],join='outer',axis=1)

AllAssetClasses.plot()

AllAssetClasses = AllAssetClasses.resample('BM').last()

Returns = AllAssetClasses.pct_change(1)
EReturns = pd.DataFrame()
for asset_class in Returns.columns:
    EReturns[asset_class] = Returns[asset_class] - Returns['CDI']

EReturns = EReturns.drop('CDI',axis=1)


# serie diaria
AllAssetClasses_daily = pd.DataFrame()

for asset_class_daily in TimeSeriesXL.sheet_names:
    print(asset_class_daily)
    df = TimeSeriesXL.parse(asset_class_daily, index_col=0, skiprows=1)
    df.columns = [asset_class_daily]
    df.index.name = 'Dates'
    AllAssetClasses_daily = pd.concat([AllAssetClasses_daily,df],join='outer',axis=1)

Returns_daily = AllAssetClasses_daily.pct_change(1)
EReturns_daily = pd.DataFrame()
for asset_class_daily in Returns.columns:
    EReturns_daily[asset_class_daily] = Returns_daily[asset_class_daily] - Returns_daily['CDI']

EReturns_daily = EReturns_daily.drop('CDI',axis=1)
EReturns_daily = EReturns_daily.dropna()

for asset_class in EReturns.columns:

    # Fato 1 - FAC decai linearmente, FACP só do 1o lag
    TS_in_levels = AllAssetClasses[asset_class].dropna()
    fig = plt.figure(figsize=(12,8))
    ax1 = fig.add_subplot(211)
    fig = sm.graphics.tsa.plot_acf(TS_in_levels.values.squeeze(), lags=40, ax=ax1)
    ax2 = fig.add_subplot(212)
    fig = sm.graphics.tsa.plot_pacf(TS_in_levels, lags=40, ax=ax2)
    plt.savefig(asset_class + '_FAC_levels.pdf')

    # Fato 2 - serie dos preços nao rejeita hip raiz unitaria
    from statsmodels.tsa.stattools import adfuller
    unit_root_test = adfuller(TS_in_levels)
    test_out = pd.Series(unit_root_test[0:4], index = ['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    print('Results of Dickey-Fuller Test:')    
    for key, value in unit_root_test[4].items():
        test_out['Critical Value (%s)' %key] = value
    print(test_out)
    
    # Fato 3 - FAC e FACP dos retornos = 0
    TS_in_returns = EReturns[asset_class].dropna()
    fig = plt.figure(figsize=(12,8))
    ax1 = fig.add_subplot(211)
    fig = sm.graphics.tsa.plot_acf(TS_in_returns.values.squeeze(), lags=40, ax=ax1)
    ax2 = fig.add_subplot(212)
    fig = sm.graphics.tsa.plot_pacf(TS_in_returns, lags=40, ax=ax2)
    plt.savefig(asset_class + '_FAC_returns.pdf')
    
    # Fato 4 - media dos retornos > 0
    returns_summary = TS_in_returns.describe()
    t_stat = returns_summary[1] / returns_summary[2]
    print('T-statistc = %f' %t_stat)
    fig = plt.figure(figsize = (12, 8))
    ax = fig.add_subplot(111)
    fig = plt.hist(TS_in_returns, zorder = 3)
    plt.xlabel('Returns')
    plt.ylabel('Density')
    plt.grid(color = 'gray', linestyle = 'dashed', zorder = 0)
    plt.savefig(asset_class + '_returns_histogram.pdf')
        
    # Fato 5 - caudas largas
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111)
    fig = qqplot(TS_in_returns, line='q', ax=ax, fit=True)
    plt.savefig(asset_class + '_returns_qqplot.pdf')
    
    # Fato 6 - cluster de volatilidade
    # regressao retornos^2
    TS_in_returns_2 = TS_in_returns.apply(lambda x: x**2)
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111)
    fid = TS_in_returns_2.plot()
    plt.savefig(asset_class + 'returns_plot.pdf')
        
    arma_mod20 = sm.tsa.ARMA(TS_in_returns_2, (1, 0)).fit()
    print(arma_mod20.summary())

    #Fato 7 - maior volatilidade na abertura do fds
    
    TS_in_returns_daily = EReturns_daily[asset_class].dropna()
    TS_in_returns_daily_2 = TS_in_returns_daily.apply(lambda x: x**2)
    lag_return = TS_in_returns_daily_2.shift()
    days_diff = TS_in_returns_daily_2.index.to_series().diff().dt.days
    daily_returns_2_df = pd.DataFrame(TS_in_returns_daily_2)
    daily_returns_2_df['lagged_return'] = lag_return.dropna()
    daily_returns_2_df['days_diff'] = np.where(days_diff > 1, 1, 0)
    daily_returns_2_df['return'] = TS_in_returns_daily

    import statsmodels.formula.api as smf    
    reg_7 = smf.ols(formula = 'DebenturesIPCA ~ lagged_return + lagged_return * days_diff', data = daily_returns_2_df).fit()
    reg_7.summary()    
    
    # Fato 9 - leverage effect
    monthly_returns_df = pd.DataFrame()
    monthly_returns_df['returns'] = TS_in_returns
    monthly_returns_df['return_square'] = TS_in_returns_2
    monthly_returns_df['lagged_return'] = TS_in_returns.shift()
    monthly_returns_df['lagged_return_square'] = TS_in_returns_2.shift()
    monthly_returns_df['neg_return'] = np.where(monthly_returns_df['lagged_return']<0,1,0)
    
    reg_9 = smf.ols(formula = 'return_square ~ lagged_return_square + lagged_return_square*neg_return', data = monthly_returns_df).fit()
    reg_9.summary()
    